plugins {
    id("com.android.application")
}

android {
    namespace = "com.delmond.firewater"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.delmond.firewater"
        minSdk = 29
        targetSdk = 37
        versionCode = 5
        versionName = "0.3.0-voice-demo"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
