package com.delmond.firewater.audio

import android.content.Context
import android.media.MediaPlayer
import com.delmond.firewater.R
import com.delmond.firewater.game.MusicMood

class AudioMoodController(private val context: Context) {
    private var player: MediaPlayer? = null
    private var current: MusicMood? = null
    var enabled: Boolean = true

    fun setMood(mood: MusicMood) {
        if (current == mood && player?.isPlaying == true) return
        current = mood
        if (enabled) play(mood)
    }

    private fun play(mood: MusicMood) {
        release()
        val res = when (mood) {
            MusicMood.ROMANTIC -> R.raw.romantic_ambient
            MusicMood.MYSTIC -> R.raw.mystic_ambient
            MusicMood.TECHNO_CHAOS -> R.raw.techno_chaos
        }
        player = MediaPlayer.create(context, res)?.apply {
            isLooping = true
            setVolume(0.20f, 0.20f)
            start()
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (!value) release() else current?.let { play(it) }
    }

    fun duckForVoice(duck: Boolean) {
        player?.setVolume(if (duck) 0.07f else 0.20f, if (duck) 0.07f else 0.20f)
    }

    fun release() {
        try { player?.stop() } catch (_: Throwable) {}
        player?.release()
        player = null
    }
}
