package com.delmond.firewater.game

object HostPersona {
    fun phrase(state: GameState, card: GameCard): String {
        val lead = when (state.host) {
            HostProfile.MALE -> maleLead(state, card)
            HostProfile.FEMALE -> femaleLead(state, card)
        }
        return "$lead ${card.text}"
    }

    private fun maleLead(state: GameState, card: GameCard): String = when {
        state.intensityTarget <= 1 && card.type == CardType.QUESTION -> "Не спешите. Сначала просто услышьте друг друга."
        state.intensityTarget <= 1 -> "Хорошо. Сделаем это спокойно."
        state.intensityTarget == 2 && card.type == CardType.QUESTION -> "Теперь чуть честнее. Без правильных ответов."
        state.intensityTarget == 2 -> "Идём ближе, но только в вашем темпе."
        state.intensityTarget == 3 && card.type == CardType.QUESTION -> "Сейчас можно быть откровеннее."
        state.intensityTarget == 3 -> "Следующий шаг чувственнее. Любое «стоп» важнее игры."
        else -> "Хорошо. Дальше только то, чего хотите вы оба."
    }

    private fun femaleLead(state: GameState, card: GameCard): String = when {
        state.intensityTarget <= 1 && card.type == CardType.QUESTION -> "Оставьте спешку за дверью. Послушайте ответ до конца."
        state.intensityTarget <= 1 -> "Начнём мягко. Пусть вечер сам набирает температуру."
        state.intensityTarget == 2 && card.type == CardType.QUESTION -> "А теперь немного ближе к тому, что обычно остаётся между строк."
        state.intensityTarget == 2 -> "Добавим искры. Но без гонки."
        state.intensityTarget == 3 && card.type == CardType.QUESTION -> "Можно сказать чуть больше, чем обычно."
        state.intensityTarget == 3 -> "Сейчас будет чувственнее. Вы в любой момент можете сделать шаг назад."
        else -> "Дальше — только взаимное желание. Никаких догадок за другого."
    }

    fun consentPrompt(host: HostProfile): String = when (host) {
        HostProfile.MALE -> "Дальше начинается взрослый интимный этап. Он открывается только если вы оба совершеннолетние и оба этого хотите. Скажите: оба согласны. Или: не сегодня."
        HostProfile.FEMALE -> "Следующая часть заметно интимнее. Никаких догадок: только согласие двоих взрослых. Скажите: оба согласны. Или: не сегодня."
    }
}
