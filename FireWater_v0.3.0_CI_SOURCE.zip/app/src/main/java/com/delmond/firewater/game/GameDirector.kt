package com.delmond.firewater.game

import kotlin.math.abs
import kotlin.random.Random

class GameDirector(
    private val cards: List<GameCard>,
    private val random: Random = Random.Default
) {
    var state: GameState = GameState()
        private set

    private var manualPaceHoldUntilTurn: Int = 0

    fun resetSession(): GameState {
        val host = state.host
        val music = state.musicMood
        manualPaceHoldUntilTurn = 0
        state = GameState(host = host, musicMood = music)
        return state
    }

    fun start(): GameState {
        state = state.copy(started = true, paused = false, stopped = false, turn = 0)
        return next()
    }

    fun next(): GameState {
        if (!state.started || state.stopped) return state
        if (state.paused) return state

        applyGuidedPacing()

        val eligible = cards.filter { card ->
            card.id !in state.seenIds &&
            card.intensity <= state.intensityTarget &&
            (!card.requiresAdultConsent || state.adultConsent)
        }

        val pool = if (eligible.isNotEmpty()) eligible else cards.filter { card ->
            card.intensity <= state.intensityTarget &&
            (!card.requiresAdultConsent || state.adultConsent)
        }

        if (pool.isEmpty()) return state

        val scored = pool.map { it to score(it) }
        val bestScore = scored.maxOf { it.second }
        val shortlist = scored.filter { it.second >= bestScore - 2 }.map { it.first }
        val chosen = shortlist.random(random)

        state = state.copy(
            currentCard = chosen,
            seenIds = state.seenIds + chosen.id,
            turn = state.turn + 1
        )
        return state
    }

    private fun score(card: GameCard): Int {
        val d = card.dimensions
        var score = 20 - abs(card.intensity - state.intensityTarget) * 6
        score += 5 - abs(d.romance - state.romance)
        score += 5 - abs(d.flirt - state.flirt)
        score += 5 - abs(d.openness - state.openness)
        score += 5 - abs(d.touch - state.touch)
        if (card.id in state.skippedIds) score -= 8
        val previousType = state.currentCard?.type
        if (previousType != null && card.type != previousType) score += 4
        return score
    }

    private fun applyGuidedPacing() {
        if (state.adultConsent || state.turn < manualPaceHoldUntilTurn) return
        val guided = when {
            state.turn >= 9 -> 3
            state.turn >= 4 -> 2
            else -> state.intensityTarget
        }
        if (guided > state.intensityTarget) state = state.copy(intensityTarget = guided)
    }

    fun skip(): GameState {
        state.currentCard?.let { state = state.copy(skippedIds = state.skippedIds + it.id) }
        return next()
    }

    fun softer(): GameState {
        manualPaceHoldUntilTurn = state.turn + 3
        state = state.copy(
            intensityTarget = (state.intensityTarget - 1).coerceAtLeast(0),
            touch = (state.touch - 1).coerceAtLeast(0),
            openness = (state.openness - 1).coerceAtLeast(0)
        )
        return next()
    }

    fun bolder(): GameState {
        manualPaceHoldUntilTurn = state.turn + 3
        val nextLevel = (state.intensityTarget + 1).coerceAtMost(if (state.adultConsent) 4 else 3)
        state = state.copy(
            intensityTarget = nextLevel,
            flirt = (state.flirt + 1).coerceAtMost(5),
            touch = (state.touch + 1).coerceAtMost(5)
        )
        return next()
    }

    fun moreFlirt(): GameState {
        state = state.copy(flirt = (state.flirt + 2).coerceAtMost(5), romance = (state.romance - 1).coerceAtLeast(0))
        return next()
    }

    fun moreRomance(): GameState {
        state = state.copy(romance = (state.romance + 2).coerceAtMost(5), flirt = (state.flirt - 1).coerceAtLeast(0))
        return next()
    }

    fun lessPersonal(): GameState {
        state = state.copy(openness = (state.openness - 2).coerceAtLeast(0))
        return next()
    }

    fun pause(): GameState { state = state.copy(paused = true); return state }
    fun resume(): GameState { state = state.copy(paused = false); return state }
    fun stop(): GameState { state = state.copy(stopped = true, paused = true); return state }

    fun setHost(host: HostProfile): GameState { state = state.copy(host = host); return state }
    fun setMusic(mood: MusicMood): GameState { state = state.copy(musicMood = mood); return state }

    fun grantAdultConsent(): GameState {
        manualPaceHoldUntilTurn = Int.MAX_VALUE
        state = state.copy(adultConsent = true, intensityTarget = 4)
        return next()
    }

    fun denyAdultConsent(): GameState {
        state = state.copy(adultConsent = false, intensityTarget = state.intensityTarget.coerceAtMost(3))
        return state
    }

    fun needsConsentGate(): Boolean = !state.adultConsent && state.intensityTarget >= 3
}
