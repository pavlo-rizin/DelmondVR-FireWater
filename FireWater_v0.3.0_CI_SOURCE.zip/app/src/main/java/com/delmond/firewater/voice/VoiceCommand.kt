package com.delmond.firewater.voice

sealed class VoiceCommand {
    data object Next : VoiceCommand()
    data object Repeat : VoiceCommand()
    data object Skip : VoiceCommand()
    data object Softer : VoiceCommand()
    data object Bolder : VoiceCommand()
    data object MoreFlirt : VoiceCommand()
    data object MoreRomance : VoiceCommand()
    data object LessPersonal : VoiceCommand()
    data object Pause : VoiceCommand()
    data object Continue : VoiceCommand()
    data object Stop : VoiceCommand()
    data object MaleHost : VoiceCommand()
    data object FemaleHost : VoiceCommand()
    data object ConsentYes : VoiceCommand()
    data object ConsentNo : VoiceCommand()
    data class Unknown(val raw: String) : VoiceCommand()
}
