package com.delmond.firewater.game

import android.content.Context
import org.json.JSONArray

class ContentRepository(context: Context) {
    val cards: List<GameCard>

    init {
        val json = context.assets.open("content_ru.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(json)
        cards = buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    GameCard(
                        id = o.getString("id"),
                        type = CardType.valueOf(o.getString("type")),
                        intensity = o.getInt("intensity"),
                        text = o.getString("text"),
                        dimensions = Dimensions(
                            romance = o.optInt("romance"),
                            flirt = o.optInt("flirt"),
                            openness = o.optInt("openness"),
                            touch = o.optInt("touch")
                        ),
                        requiresAdultConsent = o.optBoolean("adult", false)
                    )
                )
            }
        }
    }
}
