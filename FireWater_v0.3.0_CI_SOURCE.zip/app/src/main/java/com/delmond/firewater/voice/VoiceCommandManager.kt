package com.delmond.firewater.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class VoiceCommandManager(
    private val context: Context,
    private val onCommand: (VoiceCommand, String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onActivity: (VoiceActivityState) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onIdle: () -> Unit
) : RecognitionListener {

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var destroyed = false
    private var expectedCancel = false
    private var pendingRestart: Runnable? = null
    private var usingOnDeviceRecognizer = false
    private var forceSystemRecognizer = false

    val onDeviceAvailable: Boolean
        get() = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    val recognitionModeLabel: String
        get() = if (usingOnDeviceRecognizer) "on-device" else "системное распознавание"

    fun startListening() {
        clearPendingRestart()
        if (destroyed || active) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onActivity(VoiceActivityState.ERROR)
            onStatus("Распознавание речи недоступно на устройстве")
            onIdle()
            return
        }
        ensureRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag("ru-RU").toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, usingOnDeviceRecognizer)
        }
        try {
            expectedCancel = false
            active = true
            onActivity(VoiceActivityState.LISTENING)
            onStatus(if (usingOnDeviceRecognizer) "Слушаю · on-device" else "Слушаю · системная служба")
            recognizer?.startListening(intent)
        } catch (t: Throwable) {
            active = false
            onActivity(VoiceActivityState.ERROR)
            onStatus("Не удалось запустить микрофон: ${t.javaClass.simpleName}")
            onIdle()
        }
    }

    fun stopListening() {
        clearPendingRestart()
        expectedCancel = true
        active = false
        try { recognizer?.stopListening() } catch (_: Throwable) {}
    }

    fun cancel() {
        clearPendingRestart()
        expectedCancel = true
        active = false
        try { recognizer?.cancel() } catch (_: Throwable) {}
    }

    private fun ensureRecognizer() {
        if (recognizer != null) return
        recognizer = if (onDeviceAvailable && !forceSystemRecognizer) {
            try {
                usingOnDeviceRecognizer = true
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } catch (_: Throwable) {
                usingOnDeviceRecognizer = false
                SpeechRecognizer.createSpeechRecognizer(context)
            }
        } else {
            usingOnDeviceRecognizer = false
            SpeechRecognizer.createSpeechRecognizer(context)
        }.also { it.setRecognitionListener(this) }
    }

    fun destroy() {
        clearPendingRestart()
        destroyed = true
        active = false
        expectedCancel = true
        try { recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = null
    }

    override fun onReadyForSpeech(params: Bundle?) { onActivity(VoiceActivityState.LISTENING); onStatus("Говорите") }
    override fun onBeginningOfSpeech() { onActivity(VoiceActivityState.HEARING); onStatus("Слышу…") }
    override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB - 1f) / 9f).coerceIn(0f, 1f)) }
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { onActivity(VoiceActivityState.PROCESSING); onLevel(0f); onStatus("Распознаю…") }

    override fun onError(error: Int) {
        active = false
        if (expectedCancel) {
            expectedCancel = false
            return
        }
        onLevel(0f)
        if (usingOnDeviceRecognizer && (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
            try { recognizer?.destroy() } catch (_: Throwable) {}
            recognizer = null
            usingOnDeviceRecognizer = false
            forceSystemRecognizer = true
            onActivity(VoiceActivityState.IDLE)
            onStatus("Русская on-device модель недоступна · переключаюсь на системное распознавание")
            restartAfter(550)
            return
        }
        onActivity(VoiceActivityState.ERROR)
        val message = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Ошибка аудио [$error]"
            SpeechRecognizer.ERROR_CLIENT -> "Сеанс распознавания завершён [$error]"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения на микрофон [$error]"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Ошибка сети/службы распознавания [$error]"
            SpeechRecognizer.ERROR_NO_MATCH -> "Команда не распознана [$error]"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознавание занято [$error]"
            SpeechRecognizer.ERROR_SERVER -> "Ошибка службы распознавания [$error]"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ничего не услышал [$error]"
            else -> "Ошибка распознавания [$error]"
        }
        onStatus(message)
        onIdle()
    }

    override fun onResults(results: Bundle?) {
        active = false
        onLevel(0f)
        onActivity(VoiceActivityState.PROCESSING)
        val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val raw = texts.firstOrNull().orEmpty()
        if (raw.isBlank()) {
            onStatus("Команда не распознана")
            onIdle()
            return
        }
        onStatus("«$raw»")
        onCommand(VoiceCommandParser.parse(raw), raw)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val raw = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!raw.isNullOrBlank()) onStatus("$raw…")
    }

    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    fun restartAfter(delayMs: Long = 450L) {
        if (destroyed) return
        clearPendingRestart()
        val runnable = Runnable {
            pendingRestart = null
            startListening()
        }
        pendingRestart = runnable
        main.postDelayed(runnable, delayMs)
    }

    private fun clearPendingRestart() {
        pendingRestart?.let(main::removeCallbacks)
        pendingRestart = null
    }
}
