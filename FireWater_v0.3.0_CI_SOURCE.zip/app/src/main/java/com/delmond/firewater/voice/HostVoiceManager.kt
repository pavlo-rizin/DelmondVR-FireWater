package com.delmond.firewater.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.delmond.firewater.game.HostProfile
import java.util.Locale
import java.util.UUID

class HostVoiceManager(
    context: Context,
    private val onDone: () -> Unit,
    private val onStatus: (String) -> Unit
) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context, this)
    private var ready = false
    var profile: HostProfile = HostProfile.MALE
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) {
            onStatus("Системный голос ведущего недоступен")
            return
        }
        tts.language = Locale.forLanguageTag("ru-RU")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { onDone() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { onDone() }
        })
        applyProfile(profile)
        onStatus("Голос ведущего готов")
    }

    fun setProfile(newProfile: HostProfile) {
        profile = newProfile
        applyProfile(newProfile)
    }

    private fun applyProfile(p: HostProfile) {
        if (!ready) return
        when (p) {
            HostProfile.MALE -> {
                tts.setPitch(0.72f)
                tts.setSpeechRate(0.88f)
            }
            HostProfile.FEMALE -> {
                tts.setPitch(1.08f)
                tts.setSpeechRate(0.92f)
            }
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) {
            onDone()
            return
        }
        if (!ready) {
            onStatus("Голос ещё не готов — продолжаю без озвучки")
            onDone()
            return
        }
        val params = Bundle()
        val result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
        if (result == TextToSpeech.ERROR) {
            onStatus("Ошибка синтеза речи")
            onDone()
        }
    }

    fun stop() { if (ready) tts.stop() }
    fun shutdown() { tts.shutdown() }
}
