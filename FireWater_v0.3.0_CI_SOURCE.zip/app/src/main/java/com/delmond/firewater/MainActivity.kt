package com.delmond.firewater

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import com.delmond.firewater.audio.AudioMoodController
import com.delmond.firewater.game.ContentRepository
import com.delmond.firewater.game.GameDirector
import com.delmond.firewater.game.HostPersona
import com.delmond.firewater.game.HostProfile
import com.delmond.firewater.game.MusicMood
import com.delmond.firewater.ui.FireWaterScreen
import com.delmond.firewater.voice.HostVoiceManager
import com.delmond.firewater.voice.VoiceCommand
import com.delmond.firewater.voice.VoiceCommandManager
import com.delmond.firewater.voice.VoiceActivityState

class MainActivity : Activity() {
    private lateinit var screen: FireWaterScreen
    private lateinit var director: GameDirector
    private lateinit var voice: VoiceCommandManager
    private lateinit var hostVoice: HostVoiceManager
    private lateinit var audio: AudioMoodController

    private var handsFree = true
    private var permissionRequestPending = false
    private var consentDialog: AlertDialog? = null
    private var foregroundActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        director = GameDirector(ContentRepository(this).cards)
        audio = AudioMoodController(this)
        screen = FireWaterScreen(this)
        setContentView(screen)

        voice = VoiceCommandManager(
            context = this,
            onCommand = { command, raw -> runOnUiThread { screen.setTranscript("Вы: $raw"); handleVoice(command) } },
            onStatus = { status -> runOnUiThread { screen.setVoiceStatus(status) } },
            onActivity = { state -> runOnUiThread { screen.setVoiceMode(state) } },
            onLevel = { level -> runOnUiThread { screen.setVoiceLevel(level) } },
            onIdle = { runOnUiThread { restartVoiceIfAppropriate(850) } }
        )

        hostVoice = HostVoiceManager(
            context = this,
            onDone = {
                runOnUiThread {
                    audio.duckForVoice(false)
                    screen.setVoiceMode(VoiceActivityState.IDLE)
                    restartVoiceIfAppropriate(500)
                }
            },
            onStatus = { status -> runOnUiThread { screen.setVoiceStatus(status) } }
        )

        bindUi()
        audio.setMood(MusicMood.ROMANTIC)
        screen.render(director.state)
        ensureMicPermission()
    }

    private fun bindUi() {
        screen.onMic = {
            if (hasMicPermission()) {
                handsFree = true
                voice.startListening()
            } else {
                ensureMicPermission()
            }
        }
        screen.onNext = { next() }
        screen.onRepeat = {
            if (!director.state.started || director.state.stopped) next()
            else director.state.currentCard?.let { speak(HostPersona.phrase(director.state, it)) }
        }
        screen.onPauseToggle = {
            if (!director.state.started || director.state.stopped) {
                next()
            } else if (director.state.paused) {
                director.resume()
                screen.render(director.state)
                speak("Продолжаем.")
            } else {
                director.pause()
                screen.render(director.state)
                speak("Пауза. Я продолжу слушать только команды продолжить или стоп.")
            }
        }
        screen.onStop = { if (director.state.started && !director.state.stopped) stopGame() }
        screen.onSkip = { ifStarted { present(director.skip()) } }
        screen.onConsent = { showConsentGate() }
        screen.onSettings = { showSettingsMenu() }
    }

    private fun next() {
        if (director.state.stopped) {
            handsFree = true
            director.resetSession()
        }
        val state = if (!director.state.started) director.start() else director.next()
        present(state)
    }

    private fun ifStarted(block: () -> Unit) {
        if (!director.state.started) next() else block()
    }

    private fun handleVoice(command: VoiceCommand) {
        if (consentDialog?.isShowing == true) {
            when (command) {
                VoiceCommand.ConsentYes -> acceptAdultConsent()
                VoiceCommand.ConsentNo -> declineAdultConsent()
                VoiceCommand.Stop -> stopGame()
                else -> speak("Для этого шага скажите: оба согласны, или: не сегодня.")
            }
            return
        }

        if (director.state.paused && !director.state.stopped) {
            when (command) {
                VoiceCommand.Continue -> {
                    director.resume()
                    screen.render(director.state)
                    speak("Продолжаем.")
                }
                VoiceCommand.Stop -> stopGame()
                else -> speak("Игра на паузе. Скажите: продолжить, или: стоп.")
            }
            return
        }

        when (command) {
            VoiceCommand.Next -> next()
            VoiceCommand.Repeat -> director.state.currentCard?.let { speak(HostPersona.phrase(director.state, it)) }
            VoiceCommand.Skip -> ifStarted { present(director.skip()) }
            VoiceCommand.Softer -> ifStarted { present(director.softer()) }
            VoiceCommand.Bolder -> ifStarted {
                if (!director.state.adultConsent && director.state.intensityTarget >= 3) showConsentGate()
                else present(director.bolder())
            }
            VoiceCommand.MoreFlirt -> ifStarted { present(director.moreFlirt()) }
            VoiceCommand.MoreRomance -> ifStarted { present(director.moreRomance()) }
            VoiceCommand.LessPersonal -> ifStarted { present(director.lessPersonal()) }
            VoiceCommand.Pause -> {
                director.pause()
                screen.render(director.state)
                speak("Пауза. Я продолжу слушать только команды продолжить или стоп.")
            }
            VoiceCommand.Continue -> {
                // Outside pause, “продолжить/продолжай” means advance the session.
                next()
            }
            VoiceCommand.Stop -> stopGame()
            VoiceCommand.MaleHost -> {
                director.setHost(HostProfile.MALE)
                hostVoice.setProfile(HostProfile.MALE)
                screen.render(director.state)
                speak("Хорошо. Теперь веду я.")
            }
            VoiceCommand.FemaleHost -> {
                director.setHost(HostProfile.FEMALE)
                hostVoice.setProfile(HostProfile.FEMALE)
                screen.render(director.state)
                speak("Хорошо. Теперь веду я.")
            }
            VoiceCommand.ConsentYes, VoiceCommand.ConsentNo -> {
                screen.setVoiceStatus("Сейчас подтверждение 18+ не запрашивается")
                restartVoiceIfAppropriate(850)
            }
            is VoiceCommand.Unknown -> {
                screen.setVoiceStatus("Команда не распознана. Скажите «дальше», «повтори», «нежнее», «смелее» или «пропусти».")
                restartVoiceIfAppropriate(900)
            }
        }
    }

    private fun stopGame() {
        director.stop()
        handsFree = false
        consentDialog?.dismiss()
        consentDialog = null
        voice.cancel()
        screen.render(director.state)
        speak("Игра остановлена.")
    }

    private fun present(state: com.delmond.firewater.game.GameState, speakCard: Boolean = true) {
        screen.render(state)
        audio.setMood(state.musicMood)
        hostVoice.setProfile(state.host)
        if (speakCard) state.currentCard?.let { speak(HostPersona.phrase(state, it)) }
    }

    private fun speak(text: String) {
        voice.cancel()
        screen.setVoiceMode(VoiceActivityState.SPEAKING)
        screen.setVoiceStatus("Ведущий говорит")
        audio.duckForVoice(true)
        hostVoice.speak(text)
    }


    private fun showSettingsMenu() {
        val items = arrayOf(
            "Мужской ведущий",
            "Женский ведущий",
            "Музыка · романтика",
            "Музыка · мистика",
            "Музыка · техно-хаос",
            "Нежнее",
            "Смелее",
            "Остановить игру"
        )
        AlertDialog.Builder(this)
            .setTitle("Настройки сессии")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { director.setHost(HostProfile.MALE); hostVoice.setProfile(HostProfile.MALE); screen.render(director.state); speak("Мужской ведущий выбран.") }
                    1 -> { director.setHost(HostProfile.FEMALE); hostVoice.setProfile(HostProfile.FEMALE); screen.render(director.state); speak("Женский ведущий выбран.") }
                    2 -> { director.setMusic(MusicMood.ROMANTIC); audio.setMood(MusicMood.ROMANTIC); screen.render(director.state) }
                    3 -> { director.setMusic(MusicMood.MYSTIC); audio.setMood(MusicMood.MYSTIC); screen.render(director.state) }
                    4 -> { director.setMusic(MusicMood.TECHNO_CHAOS); audio.setMood(MusicMood.TECHNO_CHAOS); screen.render(director.state) }
                    5 -> ifStarted { present(director.softer()) }
                    6 -> ifStarted { if (!director.state.adultConsent && director.state.intensityTarget >= 3) showConsentGate() else present(director.bolder()) }
                    7 -> if (director.state.started && !director.state.stopped) stopGame()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showConsentGate() {
        if (consentDialog?.isShowing == true) return
        voice.cancel()

        val dialog = AlertDialog.Builder(this)
            .setTitle("Интимный этап · 18+")
            .setMessage(
                "Открыть уровень 4 можно только если оба игрока совершеннолетние и оба хотят продолжить. " +
                    "Любое задание можно пропустить, а согласие можно отозвать в любой момент. Ответы игроков приложение не сохраняет."
            )
            .setPositiveButton("Оба 18+ и согласны") { _, _ -> acceptAdultConsent() }
            .setNegativeButton("Не сегодня") { _, _ -> declineAdultConsent() }
            .setOnCancelListener { restartVoiceIfAppropriate() }
            .create()

        dialog.setOnDismissListener {
            if (consentDialog === dialog) consentDialog = null
        }
        consentDialog = dialog
        dialog.show()
        speak(HostPersona.consentPrompt(director.state.host))
    }

    private fun acceptAdultConsent() {
        consentDialog?.dismiss()
        consentDialog = null
        present(director.grantAdultConsent())
    }

    private fun declineAdultConsent() {
        consentDialog?.dismiss()
        consentDialog = null
        director.denyAdultConsent()
        screen.render(director.state)
        speak("Хорошо. Остаёмся в чувственном режиме без перехода к взрослому этапу.")
    }

    private fun restartVoiceIfAppropriate(delayMs: Long = 450L) {
        if (foregroundActive && handsFree && hasMicPermission() && !director.state.stopped) {
            voice.restartAfter(delayMs)
        }
    }

    private fun ensureMicPermission() {
        if (hasMicPermission() || permissionRequestPending) {
            if (hasMicPermission()) {
                screen.setVoiceStatus(if (voice.onDeviceAvailable) "Микрофон готов · on-device доступен" else "Микрофон готов · системное распознавание")
            }
            return
        }
        permissionRequestPending = true
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
    }

    private fun hasMicPermission(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_REQUEST) {
            permissionRequestPending = false
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                handsFree = true
                screen.setVoiceStatus(if (voice.onDeviceAvailable) "Микрофон разрешён · on-device доступен" else "Микрофон разрешён · системное распознавание")
                restartVoiceIfAppropriate()
            } else {
                handsFree = false
                screen.setVoiceMode(VoiceActivityState.ERROR)
                screen.showFallback(true)
                screen.setVoiceStatus("Микрофон запрещён. Открыто резервное кнопочное управление.")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        foregroundActive = true
        if (::voice.isInitialized) restartVoiceIfAppropriate(700)
    }

    override fun onPause() {
        foregroundActive = false
        if (::voice.isInitialized) voice.cancel()
        if (::hostVoice.isInitialized) hostVoice.stop()
        if (::audio.isInitialized) audio.duckForVoice(false)
        super.onPause()
    }

    override fun onDestroy() {
        consentDialog?.dismiss()
        if (::voice.isInitialized) voice.destroy()
        if (::hostVoice.isInitialized) hostVoice.shutdown()
        if (::audio.isInitialized) audio.release()
        super.onDestroy()
    }

    companion object {
        private const val MIC_REQUEST = 4101
    }
}
