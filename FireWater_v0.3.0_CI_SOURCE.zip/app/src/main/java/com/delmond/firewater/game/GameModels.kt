package com.delmond.firewater.game

enum class CardType { QUESTION, TASK, CHOICE, CONSENT }
enum class HostProfile { MALE, FEMALE }
enum class MusicMood { ROMANTIC, MYSTIC, TECHNO_CHAOS }

data class Dimensions(
    val romance: Int = 0,
    val flirt: Int = 0,
    val openness: Int = 0,
    val touch: Int = 0
)

data class GameCard(
    val id: String,
    val type: CardType,
    val intensity: Int,
    val text: String,
    val dimensions: Dimensions = Dimensions(),
    val requiresAdultConsent: Boolean = false
)

data class GameState(
    val started: Boolean = false,
    val paused: Boolean = false,
    val stopped: Boolean = false,
    val host: HostProfile = HostProfile.MALE,
    val musicMood: MusicMood = MusicMood.ROMANTIC,
    val intensityTarget: Int = 1,
    val romance: Int = 2,
    val flirt: Int = 2,
    val openness: Int = 2,
    val touch: Int = 1,
    val adultConsent: Boolean = false,
    val currentCard: GameCard? = null,
    val seenIds: Set<String> = emptySet(),
    val skippedIds: Set<String> = emptySet(),
    val turn: Int = 0
)
