package com.delmond.firewater.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import com.delmond.firewater.voice.VoiceActivityState
import kotlin.math.sin

class VoiceOrbView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val start = SystemClock.uptimeMillis()
    private var level = 0f
    private var state = VoiceActivityState.IDLE
    private var intensity = 1

    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setVoiceState(value: VoiceActivityState) {
        state = value
        invalidate()
    }

    fun setIntensity(value: Int) {
        intensity = value.coerceIn(0, 4)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.28f
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val breathing = 1f + 0.025f * sin(t * 2.1f)
        val activityBoost = when (state) {
            VoiceActivityState.HEARING -> 0.16f + level * 0.22f
            VoiceActivityState.LISTENING -> 0.07f + level * 0.10f
            VoiceActivityState.PROCESSING -> 0.10f
            VoiceActivityState.SPEAKING -> 0.12f
            VoiceActivityState.ERROR -> 0.03f
            else -> 0.02f
        }
        val radius = base * breathing * (1f + activityBoost)
        val warmth = 120 + intensity * 22
        val cool = 165 + (4 - intensity) * 14

        paint.shader = RadialGradient(
            cx - radius * .32f, cy + radius * .08f, radius * 1.55f,
            intArrayOf(Color.argb(235, warmth.coerceAtMost(255), 52, 28), Color.argb(50, 120, 25, 20), Color.TRANSPARENT),
            floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.42f, paint)

        paint.shader = RadialGradient(
            cx + radius * .34f, cy - radius * .08f, radius * 1.55f,
            intArrayOf(Color.argb(225, 18, 108, cool.coerceAtMost(255)), Color.argb(48, 10, 44, 94), Color.TRANSPARENT),
            floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.42f, paint)

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(2f)
        paint.color = when (state) {
            VoiceActivityState.ERROR -> Color.argb(230, 255, 95, 95)
            VoiceActivityState.HEARING -> Color.argb(245, 255, 255, 255)
            VoiceActivityState.SPEAKING -> Color.argb(240, 255, 210, 150)
            else -> Color.argb(175, 235, 242, 255)
        }
        canvas.drawCircle(cx, cy, radius * (0.95f + level * .10f), paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(220, 255, 255, 255)
        val micW = radius * .18f
        val micH = radius * .32f
        canvas.drawRoundRect(cx - micW, cy - micH, cx + micW, cy + micH * .55f, micW, micW, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(4f)
        canvas.drawArc(cx - micW * 1.6f, cy - micH * .15f, cx + micW * 1.6f, cy + micH * 1.05f, 0f, 180f, false, paint)
        canvas.drawLine(cx, cy + micH * 1.05f, cx, cy + micH * 1.42f, paint)
        canvas.drawLine(cx - micW * .8f, cy + micH * 1.42f, cx + micW * .8f, cy + micH * 1.42f, paint)

        paint.style = Paint.Style.FILL
        postInvalidateOnAnimation()
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
