package com.delmond.firewater.voice

import java.util.Locale

object VoiceCommandParser {
    fun parse(raw: String): VoiceCommand {
        val normalized = raw.lowercase(Locale.forLanguageTag("ru-RU"))
            .replace('ё', 'е')
            .replace(Regex("[^а-яa-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val s = normalized
            .removePrefix("ведущий ")
            .removePrefix("ведущая ")
            .removePrefix("игра ")
            .trim()

        fun exact(vararg variants: String) = variants.any { s == it }

        return when {
            exact("оба согласны", "мы согласны", "согласны оба", "да согласны", "да мы согласны") -> VoiceCommand.ConsentYes
            exact("не согласны", "не сегодня", "остаться здесь", "без секса") -> VoiceCommand.ConsentNo
            exact("женский голос", "женщина ведущая", "женский ведущий") -> VoiceCommand.FemaleHost
            exact("мужской голос", "мужчина ведущий", "мужской ведущий") -> VoiceCommand.MaleHost
            exact("больше романтики", "романтичнее") -> VoiceCommand.MoreRomance
            exact("больше флирта", "флирта больше", "пофлиртуем") -> VoiceCommand.MoreFlirt
            exact("без личных", "меньше личного", "не так лично") -> VoiceCommand.LessPersonal
            exact("повтори", "еще раз", "повторить") -> VoiceCommand.Repeat
            exact("пропусти", "пропустить", "другое задание", "следующее другое") -> VoiceCommand.Skip
            exact("нежнее", "мягче", "спокойнее", "пониже уровень") -> VoiceCommand.Softer
            exact("смелее", "откровеннее", "горячее", "повыше уровень") -> VoiceCommand.Bolder
            exact("пауза", "поставь паузу") -> VoiceCommand.Pause
            exact("продолжить", "продолжай", "снять паузу") -> VoiceCommand.Continue
            exact("стоп", "остановить игру", "закончить игру") -> VoiceCommand.Stop
            exact("начать игру", "начинаем", "начать", "дальше", "следующее") -> VoiceCommand.Next
            else -> VoiceCommand.Unknown(raw)
        }
    }
}
