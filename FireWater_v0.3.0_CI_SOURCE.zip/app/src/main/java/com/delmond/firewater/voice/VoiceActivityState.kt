package com.delmond.firewater.voice

enum class VoiceActivityState {
    IDLE,
    LISTENING,
    HEARING,
    PROCESSING,
    SPEAKING,
    ERROR
}
