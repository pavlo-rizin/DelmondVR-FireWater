package com.delmond.firewater.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import com.delmond.firewater.game.MusicMood
import kotlin.math.cos
import kotlin.math.sin

class ElementalBackgroundView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val start = SystemClock.uptimeMillis()
    private var voiceLevel = 0f
    private var intensity = 1
    private var mood = MusicMood.ROMANTIC

    fun setVoiceLevel(value: Float) {
        voiceLevel = value.coerceIn(0f, 1f)
        invalidate()
    }

    fun setIntensity(value: Int) {
        intensity = value.coerceIn(0, 4)
        invalidate()
    }

    fun setMood(value: MusicMood) {
        mood = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        canvas.drawColor(Color.rgb(5, 7, 13))

        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val pulse = 1f + voiceLevel * .12f
        val heat = (150 + intensity * 20).coerceAtMost(235)
        val fireX = w * (0.19f + 0.075f * sin(t * 0.23f))
        val fireY = h * (0.60f + 0.075f * cos(t * 0.19f))
        val waterX = w * (0.81f + 0.075f * cos(t * 0.17f))
        val waterY = h * (0.40f + 0.085f * sin(t * 0.21f))

        val fireAlpha = when (mood) {
            MusicMood.ROMANTIC -> 185
            MusicMood.MYSTIC -> 145
            MusicMood.TECHNO_CHAOS -> 205
        }
        val waterAlpha = when (mood) {
            MusicMood.ROMANTIC -> 175
            MusicMood.MYSTIC -> 210
            MusicMood.TECHNO_CHAOS -> 195
        }

        paint.shader = RadialGradient(
            fireX, fireY, w * 0.78f * pulse,
            intArrayOf(Color.argb(fireAlpha, heat, 48, 22), Color.argb(68, 78, 15, 24), Color.TRANSPARENT),
            floatArrayOf(0f, 0.48f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.shader = RadialGradient(
            waterX, waterY, w * 0.78f * pulse,
            intArrayOf(Color.argb(waterAlpha, 13, 92, 154), Color.argb(70, 9, 38, 84), Color.TRANSPARENT),
            floatArrayOf(0f, 0.50f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        val union = intensity / 4f
        val mid = w * (0.5f + 0.025f * sin(t * 0.11f))
        paint.shader = RadialGradient(
            mid, h * .52f, w * (.15f + union * .16f),
            intArrayOf(Color.argb((34 + union * 80).toInt(), 232, 226, 220), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawOval(mid - w * .24f, h * .10f, mid + w * .24f, h * .92f, paint)
        paint.shader = null

        postInvalidateOnAnimation()
    }
}
