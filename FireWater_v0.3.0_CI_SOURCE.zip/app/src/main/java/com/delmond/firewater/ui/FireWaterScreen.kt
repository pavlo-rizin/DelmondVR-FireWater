package com.delmond.firewater.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.delmond.firewater.game.GameState
import com.delmond.firewater.game.HostProfile
import com.delmond.firewater.game.MusicMood
import com.delmond.firewater.voice.VoiceActivityState

class FireWaterScreen(context: Context) : FrameLayout(context) {
    var onMic: (() -> Unit)? = null
    var onNext: (() -> Unit)? = null
    var onRepeat: (() -> Unit)? = null
    var onSkip: (() -> Unit)? = null
    var onPauseToggle: (() -> Unit)? = null
    var onStop: (() -> Unit)? = null
    var onConsent: (() -> Unit)? = null
    var onSettings: (() -> Unit)? = null

    private val backgroundView = ElementalBackgroundView(context)
    private val title = TextView(context)
    private val meta = TextView(context)
    private val card = TextView(context)
    private val voiceStatus = TextView(context)
    private val transcript = TextView(context)
    private val orb = VoiceOrbView(context)
    private val consentButton = Button(context)
    private val fallbackToggle = Button(context)
    private val fallbackRow = LinearLayout(context)
    private val pauseButton = compactButton("Пауза") { onPauseToggle?.invoke() }
    private val nextButton = compactButton("Дальше") { onNext?.invoke() }
    private var fallbackVisible = false

    init {
        addView(backgroundView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(22), dp(18), dp(16))
        }
        addView(root, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        title.apply {
            text = "МЕЖДУ ОГНЁМ И ВОДОЙ"
            setTextColor(Color.WHITE)
            textSize = 21f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = .075f
        }
        root.addView(title, lp(-1, -2, 0f, 0, 0, 0, 5))

        meta.apply {
            setTextColor(Color.argb(190, 220, 228, 240))
            textSize = 11f
            gravity = Gravity.CENTER
        }
        root.addView(meta, lp(-1, -2, 0f, 0, 0, 0, 12))

        card.apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = rounded(Color.argb(172, 7, 10, 18), Color.argb(72, 255, 255, 255), 28f)
            text = "Скажите «начать игру». Я буду вести вас голосом."
        }
        root.addView(card, lp(-1, 0, 1f, 0, 0, 0, 8))

        consentButton.apply {
            text = "18+ · подтвердить переход"
            textSize = 12f
            isAllCaps = false
            visibility = View.GONE
            setTextColor(Color.WHITE)
            background = rounded(Color.argb(175, 115, 37, 48), Color.argb(80, 255, 255, 255), 18f)
            setOnClickListener { onConsent?.invoke() }
        }
        root.addView(consentButton, lp(-1, dp(46), 0f, 0, 0, 0, 4))

        orb.isClickable = true
        orb.contentDescription = "Голосовое управление"
        orb.setOnClickListener { onMic?.invoke() }
        root.addView(orb, lp(dp(178), dp(178), 0f, 0, 0, 0, 0))

        voiceStatus.apply {
            setTextColor(Color.argb(235, 238, 243, 250))
            textSize = 13f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            gravity = Gravity.CENTER
            text = "Голосовой модуль готовится…"
        }
        root.addView(voiceStatus, lp(-1, -2, 0f, 0, 0, 0, 1))

        transcript.apply {
            setTextColor(Color.argb(165, 210, 218, 232))
            textSize = 11f
            gravity = Gravity.CENTER
            text = "Коснитесь сферы, если нужно вручную включить прослушивание"
        }
        root.addView(transcript, lp(-1, -2, 0f, 0, 0, 0, 6))

        fallbackToggle.apply {
            text = "Кнопки"
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.argb(220, 238, 242, 250))
            background = rounded(Color.argb(95, 15, 19, 29), Color.argb(55, 255, 255, 255), 16f)
            setOnClickListener { showFallback(!fallbackVisible) }
        }
        root.addView(fallbackToggle, lp(dp(108), dp(38), 0f, 0, 0, 0, 5))

        fallbackRow.apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            addView(compactButton("Повтор") { onRepeat?.invoke() }, cell())
            addView(nextButton, cell(5))
            addView(compactButton("Пропустить") { onSkip?.invoke() }, cell(5))
            addView(pauseButton, cell(5))
            addView(compactButton("⋯") { onSettings?.invoke() }, cell(5))
        }
        root.addView(fallbackRow, lp(-1, dp(43), 0f, 0, 0, 0, 0))
    }

    fun render(state: GameState) {
        card.text = when {
            state.stopped -> "Игра остановлена. Коснитесь сферы или откройте кнопки, чтобы начать новую сессию."
            state.paused -> "Пауза. Скажите «продолжить», когда будете готовы."
            state.currentCard != null -> state.currentCard.text
            else -> "Скажите «начать игру». Я буду вести вас голосом."
        }

        val host = if (state.host == HostProfile.MALE) "мужской ведущий" else "женский ведущий"
        val mood = when (state.musicMood) {
            MusicMood.ROMANTIC -> "романтика"
            MusicMood.MYSTIC -> "мистика"
            MusicMood.TECHNO_CHAOS -> "техно-хаос"
        }
        meta.text = "$host · $mood · близость ${state.intensityTarget}/4"
        consentButton.visibility = if (!state.adultConsent && state.intensityTarget >= 3) View.VISIBLE else View.GONE
        pauseButton.text = if (state.paused && !state.stopped) "Продолжить" else "Пауза"
        nextButton.text = if (state.stopped || !state.started) "Начать" else "Дальше"
        orb.setIntensity(state.intensityTarget)
        backgroundView.setIntensity(state.intensityTarget)
        backgroundView.setMood(state.musicMood)
    }

    fun setVoiceStatus(text: String) {
        voiceStatus.text = text
    }

    fun setTranscript(text: String) {
        if (text.isNotBlank()) transcript.text = text
    }

    fun setVoiceLevel(level: Float) {
        orb.setLevel(level)
        backgroundView.setVoiceLevel(level)
    }

    fun setVoiceMode(state: VoiceActivityState) {
        orb.setVoiceState(state)
    }

    fun showFallback(show: Boolean) {
        fallbackVisible = show
        fallbackRow.visibility = if (show) View.VISIBLE else View.GONE
        fallbackToggle.text = if (show) "Скрыть" else "Кнопки"
    }

    private fun compactButton(label: String, action: () -> Unit): Button = Button(context).apply {
        text = label
        textSize = 10f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setTextColor(Color.WHITE)
        background = rounded(Color.argb(115, 17, 21, 31), Color.argb(58, 255, 255, 255), 16f)
        setOnClickListener { action() }
    }

    private fun cell(left: Int = 0) = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
        if (left > 0) marginStart = dp(left)
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun lp(w: Int, h: Int, weight: Float, l: Int, t: Int, r: Int, b: Int) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
